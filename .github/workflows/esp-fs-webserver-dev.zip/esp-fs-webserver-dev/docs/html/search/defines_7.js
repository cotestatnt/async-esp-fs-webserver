var searchData=
[
  ['var_5fname_0',['VAR_NAME',['../linked__list_8h.html#ab095b1ffa740c9b6385eb9bd3f7b5d65',1,'linked_list.h']]]
];
