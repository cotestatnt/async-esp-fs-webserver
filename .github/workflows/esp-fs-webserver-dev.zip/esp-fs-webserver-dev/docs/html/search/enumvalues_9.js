var searchData=
[
  ['string_0',['STRING',['../linked__list_8h.html#adf764cbdea00d65edcd07bb9953ad2b7aee847e634a4297b274316de8a8ca9921',1,'linked_list.h']]]
];
