var searchData=
[
  ['setup_5fhtml_5fsize_0',['SETUP_HTML_SIZE',['../setup__htm_8h.html#a2159cf372aa858c3860812ab7df87cc5',1,'setup_htm.h']]]
];
