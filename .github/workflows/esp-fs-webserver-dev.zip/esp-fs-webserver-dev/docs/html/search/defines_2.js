var searchData=
[
  ['file_5fnot_5ffound_0',['FILE_NOT_FOUND',['../esp-fs-webserver_8h.html#a775241e32b7ccb12e344ae23aa2db6b1',1,'esp-fs-webserver.h']]],
  ['fs_5finit_5ferror_1',['FS_INIT_ERROR',['../esp-fs-webserver_8h.html#a53cebbc0731fee09f9592a2721834cf5',1,'esp-fs-webserver.h']]]
];
