var searchData=
[
  ['long_0',['LONG',['../linked__list_8h.html#adf764cbdea00d65edcd07bb9953ad2b7aaee055c4a5aba7d55774e4f1c01dacea',1,'linked_list.h']]]
];
