var searchData=
[
  ['type_0',['type',['../struct_var_node.html#a1806a4bee975015965499a5e1a5dbebc',1,'VarNode']]]
];
