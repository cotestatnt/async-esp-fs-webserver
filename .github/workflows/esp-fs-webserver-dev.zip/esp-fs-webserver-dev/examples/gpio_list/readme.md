In this example the content of webpage will be created at runtime with Javascript depending from a JSON list of gpios (pin number, pin label, type, actual state) received from ESP device.

![image](https://user-images.githubusercontent.com/27758688/152009153-68f3c70d-8b7f-4852-b8ad-fdccaa294d8f.png)
