#ifndef esp_fs_version_cpp
#define  esp_fs_version_cpp
#include "esp-fs-webserver.h"
const char* FSWebServer::getVersion() { 
	return "2.0.10"; 
}
#endif